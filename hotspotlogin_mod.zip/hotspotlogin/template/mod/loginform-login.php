<?php
/*
 *********************************************************************************************************
 * daloRADIUS - RADIUS Web Platform
 * Copyright (C) 2007 - Liran Tal <liran@enginx.com> All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 *********************************************************************************************************
 *
 * Authors:     Liran Tal <liran@enginx.com>
 *
 * daloRADIUS edition - fixed up variable definition through-out the code
 * as well as parted the code for the sake of modularity and ability to 
 * to support templates and languages easier.
 * Copyright (C) Enginx and Liran Tal 2007, 2008
 * 
 *********************************************************************************************************
 */

echo "
 <!DOCTYPE html>
<html>
<head>
<title> TEKS BERJALAN </title>
<body>
<marquee bgcolor='#000000' style='color:white; font-weight:bold;'>
<center> <h2>Menerima JASA Pemasangan WIFI Rumahan & CCTV Hubungi Whatsapp 081335753337</div></h2> </center>
</marquee>
<body>
<html>
<div class = 'container'>
    <div class='wrapper'>
        <form action='$loginpath' method='post' name='Login_Form' class='form-signin'>
            <input type='hidden' name='challenge' value='$challenge'>
            <input type='hidden' name='uamip' value='$uamip'>
            <input type='hidden' name='uamport' value='$uamport'>
            <input type='hidden' name='userurl' value='$userurl'>
            <h3 class='form-signin-heading'>    AREA WIFI BarokahNET    </h3
            <hr class='colorgraph'><br>
              
            <input type='text' class='form-control' name='UserName' placeholder='$centerUsername' required='' autofocus='' />
            <input type='password' class='form-control' name='Password' placeholder='$centerPassword' required=''/>
            <input type='hidden' name='button' value='Login'>
            <button class='btn btn-lg btn-primary btn-block' onClick=\'javascript:popUp('$loginpath?res=popup1&uamip=$uamip&uamport=$uamport')\'>Login</button>
        </form>         
    </div>
<!-- Menampilkan Hari, Bulan dan Tahun -->
		<center><b><script type='text/javascript'>
			<!--
			var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
			var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
			var date = new Date();
			var day = date.getDate();
			var month = date.getMonth();
			var thisDay = date.getDay(),
			    thisDay = myDays[thisDay];
			var yy = date.getYear();
			var year = (yy < 1000) ? yy + 1900 : yy;
			document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
			//-->
		</script></center></b>
		
<center><b><div id='MyClockDisplay' class='clock' onload='showTime()'></div> 
</center></b>
<b><script type='text/javascript'>function showTime(){var date=new Date(); var h=date.getHours(); var m=date.getMinutes(); var s=date.getSeconds(); var session='AM'; if(h==0){h=12;}if(h > 12){h=h - 12; session='PM';}h=(h < 10) ? '0' + h : h; m=(m < 10) ? '0' + m : m; s=(s < 10) ? '0' + s : s; var time=h + ':' + m + ':' + s + ' ' + session; document.getElementById('MyClockDisplay').innerText=time; document.getElementById('MyClockDisplay').textContent=time; setTimeout(showTime, 1000);}showTime(); </script>
</div>
             </div>
						<div class='row'>
							<div class='col-12'>
							<center><span class='blink'><br> <font color='	#006400'><b>SELAMAT MENUANAIKAN  <br> <font color='#000000'>IBADAH PUASA RAMADHAN 1444 H</blink></font></b></center>
";
echo " 
 <!DOCTYPE html>
<html>
<head>
<title> TEKS BERJALAN </title>
<body>
<marquee bgcolor='#FFD700' style='color:white; font-weight:bold;'>
<center> <h2></div></h2> </center>
</marquee>
<body>
<html>
       
       <div class='menu-items'>
            <div class='row-items'>
                <center> <br> <font color='#800000'><h2>Beli Voucher WIFI Silahkan Hubungi Whatsapp di Bawah</div></h2> </center>
            </div>
            <div class='row-items'>
                <center> <h2>081335753337</div></h2> </center>			
<center><span class='blink'><b> <font color='#000080'>Modifikasi By<b> <font color='#000080'>Boychongzen aka Xroot</font></b></small></a></span><center>

        </div>

 </form>
 <style>
.blink {
  animation: blink-animation 1s steps(5, start) infinite;
  -webkit-animation: blink-animation 1s steps(5, start) infinite;
}
@keyframes blink-animation {
  to {
    visibility: hidden;
  }
}
@-webkit-keyframes blink-animation {
  to {
    visibility: hidden;
  }
}

</script>
</div>
</div>
</div>
</div>
</body>
";