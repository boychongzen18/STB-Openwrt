<?php
# daloRADIUS edition - fixed up variable definition through-out the code
# as well as parted the code for the sake of modularity and ability to 
# to support templates and languages easier.
# Copyright (C) Enginx and Liran Tal 2007, 2008


$ChilliSpot="Hotspot";
$title="$ChilliSpot Login";
$centerUsername="Username";
$centerPassword="Password";
$centerLogin="Login";
$centerPleasewait="Tunggu sebentar.......";
$centerLogout="Keluar";
$h1Login="$ChilliSpot Login";
$h1Failed="Login GAGAL perhatikan besar kecil pada penulisan huruf, jika masih gagal bisa hubungi KAMI";
$h1Successful="<center> <h2>Akses Hotspot BarokahNET Sukses Maseee!!!!</div></h2> </center>  ";
$h1Loggedin="Login Keluar$ChilliSpot";
$h1Loggingin="Login Sukses $ChilliSpot";
$h1Loggedout="Kamu telah keluar dari $ChilliSpot";
$centerdaemon="Login must be performed through $ChilliSpot server";
$centerencrypted="Login Connection ";
?>
