<?php
/*

 */

echo "<div class='container-fluid'><div class='alert-wrapper  text-center'>";

echo "<div class='alert alert-primary text-center' role='alert'>
    $h1Loggingin";
echo "<hr><p class='mb-0'>$centerPleasewait</p>";
echo "</div>";

echo "</div></div>";
